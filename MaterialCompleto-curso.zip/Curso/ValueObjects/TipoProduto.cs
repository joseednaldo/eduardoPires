namespace CursoEFCore.ValueObjects
{
    public enum TipoProduto
    {
        MercadoriaParaRevenda,
        Embalagem,
        Servico,
    }
}