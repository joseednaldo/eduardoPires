namespace CursoEFCore.ValueObjects
{
    public enum StatusPedido
    {
        Analise,
        Finalizado,
        Entregue,
    }
}