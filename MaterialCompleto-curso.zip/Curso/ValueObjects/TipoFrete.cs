namespace CursoEFCore.ValueObjects
{
    public enum TipoFrete
    {
        CIF,
        FOB,
        SemFrete,
    }
}